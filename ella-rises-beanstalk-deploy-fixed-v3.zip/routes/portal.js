const express = require('express');
const router = express.Router();
const { isAuthenticated } = require('../middleware/auth');

// Portal home - redirect to dashboard
router.get('/', isAuthenticated, (req, res) => {
  res.redirect('/portal/dashboard');
});

// Debug Schema Route
router.get('/debug-schema', isAuthenticated, async (req, res) => {
  try {
    const db = require('../config/database');
    const tables = await db.raw("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
    
    const schema = {};
    for (const row of tables.rows) {
      const tableName = row.table_name;
      const columns = await db.raw(`SELECT column_name, data_type FROM information_schema.columns WHERE table_name = '${tableName}'`);
      schema[tableName] = columns.rows;
    }
    
    res.json(schema);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

