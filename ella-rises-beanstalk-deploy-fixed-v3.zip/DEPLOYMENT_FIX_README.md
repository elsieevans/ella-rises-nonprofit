# Deployment Fix

The previous deployment failed because the `Procfile` could not be parsed by the AWS Elastic Beanstalk rsyslog generator. This is typically due to trailing newlines or incorrect formatting.

## Changes Made
- Cleaned up `Procfile` to contain a single line: `web: node server.js`
- Verified `server.js` listens on `process.env.PORT`.

## Update v3 (Database Debugging)
- Added detailed error messages to "Error loading participant details" and "Error loading event details".
- Added a debug route `/portal/debug-schema` to inspect the database tables and columns.
- This will help identify if the `Registration` table is missing or has a schema mismatch (e.g. case sensitivity issues).

## How to Debug
1. Deploy `ella-rises-beanstalk-deploy-fixed-v3.zip`.
2. Log in to the portal.
3. Go to `/portal/debug-schema` in your browser.
4. Check if the `Registration` table exists and what its columns are named.
5. Try clicking on a participant or event again and note the specific error message displayed at the top of the page.

## How to Deploy
1. Upload `ella-rises-beanstalk-deploy-fixed-v3.zip` to AWS Elastic Beanstalk.
